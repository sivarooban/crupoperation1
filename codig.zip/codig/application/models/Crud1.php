<?php

class Crud1 extends CI_Model {
    public function __construct() {
//        parent::__construct();
        $this->load->database('default');
        $this->load->helper(array('date', 'cookie', 'url'));
    }
    public function cruddetail() {       
        $this->db->select("id,emp_name,email_id,phone_number,dob");
        $this->db->from('crud1');        
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }   
	public function cruddetail_delete($id) {       
        $this->db->where('id', $id);
        $del = $this->db->delete('crud1');
        return $del;
    } 
	public function cruddetail_insert($form_data) {              
        return $this->db->insert('crud1',$form_data);
		
    } 
	public function cruddetail_check_email($email_id) {
		$this->db->select('email_id');
		$this->db->where('email_id', $email_id);
		$result = $this->db->get('crud1');
		return $result->num_rows();						
    } 
    public function cruddetail_check_phone($phone_number) {              
        $this->db->select('phone_number');
		$this->db->where('phone_number', $phone_number);
		$result = $this->db->get('crud1');
		return $result->num_rows();
    } 
	public function cruddetail_getrecord($id) {              
        $this->db->select('*');
		$this->db->from('crud1');  
		$this->db->where('id', $id);		      
        $query = $this->db->get();
		if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }		
    } 
	public function cruddetail_update($form_data,$id){		
		$this->db->where('id',$id);
        return $this->db->update('crud1',$form_data);		
    }
	public function record_count() {		
        return $this->db->count_all("crud1");
    }
	public function record_count_search($search_field) {		
		$array = array('emp_name' => $search_field, 'email_id' => $search_field, 'phone_number' => $search_field,'dob' => $search_field);
		$this->db->from('crud1');
		$this->db->or_like($array);
        return $this->db->count_all_results();		
    }
	public function fetch_crud($limit, $start) {
        $this->db->limit($limit, $start);		
        $query = $this->db->get("crud1");
		$this->db->last_query();		
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row){
                $data[] = $row;
            }
			$this->db->last_query();
            return $data;
        }else{
			 return false;
		}		
    }
	public function fetch_crud_search($limit, $start,$search_field) {
		$array = array('emp_name' => $search_field, 'email_id' => $search_field, 'phone_number' => $search_field,'dob' => $search_field);
        $this->db->limit($limit, $start);      		
		$this->db->or_like($array);			
		$query = $this->db->get("crud1");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row){
                $data[] = $row;
            }			
            return $data;
        }else{
			 return false;
		}		
    }
	public function getData($rowno,$rowperpage) {
		$this->db->select('*');
		$this->db->from('crud1');
		$this->db->limit($rowperpage, $rowno);  
		$query = $this->db->get();
		return $query->result_array();
	}
}
