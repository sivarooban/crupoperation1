<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Crud</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<!-- jQuery library -->
	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
	<script>
		$(document).ready(function(){
			var options={
				format: 'dd/mm/yyyy',
				autoclose: true
			};
			$('#date').datepicker(options);			
		});
		$(document).on("keydown","#search_field", function (){			
			pagno         = 0;
			loadPagination(pagno);
		});	
		$(document).on("focusin","#date1", function (){
			 var options={
				format: 'dd/mm/yyyy',
				autoclose: true
			};	
			$('#date1').datepicker(options);
		});
		$(document).ready(function(){
			$('#pagination').on('click','a',function(e){
				e.preventDefault(); 
				var pageno = $(this).attr('data-ci-pagination-page');
				loadPagination(pageno); 
			});
			loadPagination(0);				
		});
		function loadPagination(pagno){
				if($('#search_field').val() != ""){
					$search_field = $("#search_field").val();					
				}else{
					$search_field = "";
				}				
				$.ajax({
					url : '<?=base_url()?>crud/loadRecord/'+pagno+'/'+$search_field,
					type: 'get',
					dataType: 'json',					
					success: function(response){					
						$('#pagination').html(response.pagination);
						createTable(response.result,response.row);
					}
			   });
			}
			function createTable(result,sno){		   
				$('#postsList tbody').empty();
				console.log(result);
				for(index in result){
					var id       = result[index].id;
					var emp_name = result[index].emp_name;
					var email_id = result[index].email_id;
					var phone_number = result[index].phone_number;
					var dob = result[index].dob;
					var link = result[index].link;
					var tr = "<tr>";
					tr += "<td>"+ id +"</td>";
					tr += "<td><a href='"+ link +"' target='_blank' >"+ emp_name +"</a></td>";
					tr += "<td>"+ email_id +"</td>";
					tr += "<td>"+ phone_number +"</td>";
					tr += "<td>"+ dob +"</td>";
					tr += "<td><a id='id_edit' href="+id+">edit</a><a href=<?=base_url()?>Operations/index?id="+id+">Delete</a></td>";
					tr += "</tr>";			 
					$('#postsList tbody').append(tr);	 
				}
			}     
		$(document).on("click","#id_edit",function() {
			 event.preventDefault();
			 $id = $(this).attr('href');
			 $.ajax({
				url: '<?php base_url()?>edit',
				type: 'POST',
				data: { id: $id} ,				
				success: function (response){
					$('#myModal_edit').modal({
						show: 'true'
					}); 
					$('.myModal_edit_body').html(response);
				},
				error: function () {
					alert("error");
				}
			}); 
		});	
	</script>
</head>
<body>

<div id="container">
	<p style="text-align:center;color:red">
		<?php if($this->session->flashdata('msg')): ?>
			<?php echo $this->session->flashdata('msg'); ?>
		<?php endif; ?>
	</p>
	<div class="topnav" style="float: right;margin-right: 80px;">		
		<input type="text" id="search_field" placeholder="Search..">
	</div>
	<div class="pagin">
		<table class="table" id="postsList">
			<thead>
			  <tr>
				<th>Employee Id</th>
				<th>Employee Name</th>
				<th>Email Id</th>
				<th>Phone Number</th>
				<th>Dob</th>
				<th>Action</th>
			  </tr>
			</thead>
			<tbody>
					
			</tbody>
		</table>
		<div id="pagination"></p>
	</div>	
   
  <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">Add</button>
	<div id="myModal" class="modal fade" role="dialog">
	  <div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Add Employee</h4>
		  </div>
		  <div class="modal-body">
			<?php $bases = base_url();?>
			<form method="post" action="<?=base_url()."index.php/Crud/add";?>">				
				<div class="row">
					<div class="col-lg-4">Employee Name</div>
					<div class="col-lg-8">
						<input type="text" required class="form-control" name="emp_name">
					</div>
				</div><br>
				<div class="row">	
					<div class="col-lg-4">Email Id</div>
					<div class="col-lg-8"><input required class="form-control" type="email" name="email_id"></div><br>
				</div><br>
				<div class="row">	
					<div class="col-lg-4">Phone Number</div>
					<div class="col-lg-8"><input required class="form-control" type="number" name="phone_number"></div><br>
				</div><br>
				<div class="row">
					<div class="col-lg-4">Date Of Birth</div>
					<div class="col-lg-8"><input readonly required class="form-control" id="date" name="dob" placeholder="DD/MM/YYY" type="text"/></div>
				</div>
				<br>
				<input type="submit">
				<input type="reset">
			</form>	
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>

	  </div>
	</div>
	<div id="myModal_edit" class="modal fade" role="dialog">
	  <div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Edit Employee</h4>
		  </div>
		  <div class="modal-body myModal_edit_body">
			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>

	  </div>
	</div>
</div>

</body>
</html>