<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	
		<table class="table">
			<thead>
			  <tr>
				<th>Employee Id</th>
				<th>Employee Name</th>
				<th>Email Id</th>
				<th>Phone Number</th>
				<th>Dob</th>
				<th>Action</th>
			  </tr>
			</thead>
			<tbody>
				<?php			
				 if(!empty($result)){
					foreach($result as $value){ 
					$result_url = base_url()."index.php/Operations?id=".$value->id; 
					$result_url1 = $value->id; ?>
					<tr>
						<td><?php echo $value->id; ?></td>
						<td><?php echo $value->emp_name; ?></td>
						<td><?php echo $value->email_id; ?></td>
						<td><?php echo $value->phone_number; ?></td>
						<td><?php echo $value->dob; ?></td>
						<td><a href="<?php echo $result_url; ?>">Delete</a>
							<a id="id_edit" href="<?php echo $result_url1; ?>">Edit</a>
						</td>
					</tr> 
				<?php } 
				} 
				?>			
			</tbody>
		</table>
		<p><?php echo $links; ?></p>
	