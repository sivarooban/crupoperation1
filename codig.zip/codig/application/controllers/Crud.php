<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct(){
        parent::__construct();
        $this->load->model('Crud1');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library("pagination");  
    }
	public function index(){		
		$config = array();
        $config["base_url"] 	= base_url();
        $config["total_rows"]   = $this->Crud1->record_count();
        $config["per_page"]     = 2;
        $config["uri_segment"]  = 3;
		$config['full_tag_open'] = "<ul class='pagination'>";
		$config['full_tag_close'] ="</ul>";
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li>";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li>";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li>";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li>";
		$config['last_tagl_close'] = "</li>";
		$this->pagination->initialize($config);
        $page 					= ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["result"] 		= $this->Crud1->fetch_crud($config["per_page"], $page);
        $data["links"] 			= $this->pagination->create_links();		
		$this->load->view('crud',$data);
	}
	public function datafetch_record5(){				
		$this->load->view('crud');
	}
	public function loadRecord($rowno=0){	
		
		if($this->uri->segment(4)){
			$search_field = $this->uri->segment(4);
		}else{
			$search_field = "";
		}
		$rowperpage = 5;
		
		// Row position
		if($rowno != 0){
		  $rowno = ($rowno-1) * $rowperpage;
		}
		if($search_field != ""){
			//echo $search_field;
			// All records count
			$allcount = $this->Crud1->record_count_search($search_field);

			// Get records
			$users_record = $this->Crud1->fetch_crud_search($rowperpage,$rowno,$search_field);
		}else{
			// All records count
			$allcount = $this->Crud1->record_count();

			// Get records
			$users_record = $this->Crud1->fetch_crud($rowperpage,$rowno);
		}
		// Pagination Configuration
		$config['base_url'] = base_url()."crud/datafetch_record5";
		$config['use_page_numbers'] = TRUE;
		$config['total_rows'] = $allcount;
		$config['per_page'] = $rowperpage;
		$config['full_tag_open'] = "<ul class='pagination'>";
		$config['full_tag_close'] ="</ul>";
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li>";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li>";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li>";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li>";
		$config['last_tagl_close'] = "</li>";
    // Initialize
    $this->pagination->initialize($config);

    // Initialize $data Array
    $data['pagination'] = $this->pagination->create_links();

    $data['result'] = $users_record;
    $data['row'] = $rowno;

    echo json_encode($data);
 
  }
	public function add(){	
		$email_id     = $this->input->post('email_id');
		$phone_number = $this->input->post('phone_number');
		if($this->Crud1->cruddetail_check_email($email_id)){
			$this->session->set_flashdata('msg', 'Email id already exist');
		}else if($this->Crud1->cruddetail_check_phone($phone_number)){
			$this->session->set_flashdata('msg', 'Phone Number already exist');
		}else{
			$form_data = array(
				'emp_name'     => $this->input->post('emp_name'),
				'email_id'     => $this->input->post('email_id'),
				'phone_number' => $this->input->post('phone_number'),
				'dob'          => $this->input->post('dob')
			);
			if($this->Crud1->cruddetail_insert($form_data)){
				$this->session->set_flashdata('msg', 'data successfully added');
			}
		}
		redirect(base_url(),"refresh");	
	}
	public function edit(){	
		$id                 = $this->input->post('id');		
		$data['result_set'] = $this->Crud1->cruddetail_getrecord($id);
		$this->load->view('crud_edit',$data);	
	}
	public function update(){
		$id = $this->input->post('id');
		$form_data = array(			
			'emp_name'     => $this->input->post('emp_name'),
			'email_id'     => $this->input->post('email_id'),
			'phone_number' => $this->input->post('phone_number'),
			'dob'          => $this->input->post('dob')
		);		
		if($this->Crud1->cruddetail_update($form_data,$id)){
			$this->session->set_flashdata('msg', 'record updated successfully');
		}		
		redirect(base_url(),"refresh");	
	}
}